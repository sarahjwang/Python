from django.contrib import admin

# Register your models here.

from backend.models import *

admin.site.register(Post)