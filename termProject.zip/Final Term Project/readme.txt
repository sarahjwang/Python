About Bloons Tower Defense 112 (BTD 112)

    This is a game that I made in Pygame using Python3 for my 15-112 Term Project at 
    Carnegie Mellon University. It is based off of Bloons Tower Defense 5, a game
    made by NinjaKiwi: http://ninjakiwi.com/Games/Tower-Defense/Bloons-Tower-Defense-5.html

    It is a tower defense game where you have to place monkeys in strategic locations
    on a map in order to pop balloons (bloons) before they get to the end of the map.
    There are two different maps to choose from. Different monkeys have different 
    attacks, while the bloons also have different features, such as strength and speed.
    After beating the 10th level, you win the game!

How to install and run Bloons Tower Defense 112

    1. Install pygame and python3

        a. Pygame: http://www.pygame.org/download.shtml

            ALSO, You can follow the instructions here after clicking the document
            pygame-install.txt: https://drive.google.com/folderview?id=0B8s_apgePQWISjItYksxN1dQN0U&usp=sharing

        b. Python3: https://www.python.org/downloads/

    2. Open game.py

    3. The game is already initialized for you, so just press cmd + B (mac) 
    or ctrl + B (on windows) to run